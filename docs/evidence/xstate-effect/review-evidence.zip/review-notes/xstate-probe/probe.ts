import { Effect, Schema } from "effect";
import { setupEffect } from "@xstate/effect";
import { describeExecutableEffect, initialTransition, isUnhandled, transition } from "xstate";
import { standardSchemaValidator } from "xstate/validation";

function check(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(message);
}
function same(actual: unknown, expected: unknown, message: string): void {
  check(JSON.stringify(actual) === JSON.stringify(expected), `${message}: ${JSON.stringify(actual)}`);
}

// This is an isolated API probe, not a product workflow or database adapter.
// No actor is started, and no clock, Promise, network or fiber is used in decide().
const machine = setupEffect({
  validator: standardSchemaValidator(),
  schemas: {
    input: Schema.Struct({ workflowId: Schema.String, approvalId: Schema.String }),
    context: Schema.Struct({ workflowId: Schema.String, approvalId: Schema.String }),
    events: {
      APPROVE: Schema.Struct({ approvalId: Schema.String, deliveryId: Schema.String }),
      COMPLETE: Schema.Struct({}),
    },
    emitted: {
      "command.submit": Schema.Struct({ commandId: Schema.String, workflowId: Schema.String }),
    },
  },
}).createMachine({
  id: "approval-probe",
  version: "1",
  context: ({ input }) => input,
  initial: "waiting",
  states: {
    waiting: {
      on: {
        APPROVE: ({ context, event }, enq) => {
          if (event.approvalId !== context.approvalId) return;
          enq.emit({
            type: "command.submit",
            commandId: `${context.workflowId}:${event.deliveryId}`,
            workflowId: context.workflowId,
          });
          return { target: "executing" };
        },
      },
    },
    executing: { on: { COMPLETE: { target: "done" } } },
    done: { type: "final" },
  },
});

const input = { workflowId: "flow-1", approvalId: "approval-7" };
const [initial, initialEffects] = initialTransition(machine, input);
same(initial.value, "waiting", "initial state");
same(initialEffects, [], "no startup effects");

const approve = { type: "APPROVE", approvalId: "approval-7", deliveryId: "evt-42" } as const;
const [next, effects] = transition(machine, initial, approve);
same(next.value, "executing", "decision advances synchronously");
same(initial.value, "waiting", "prior snapshot remains unchanged");
const descriptors = effects.map(describeExecutableEffect);
check(descriptors.length === 1 && descriptors[0].kind === "emit", "one command represented as data");
const emitted = descriptors[0];
if (emitted.kind !== "emit") throw new Error("Unexpected descriptor");
same(emitted.event, { type: "command.submit", commandId: "flow-1:evt-42", workflowId: "flow-1" }, "portable command payload");
same(JSON.parse(JSON.stringify(emitted.event)), emitted.event, "command round trips as JSON");

// Put the validator on setupEffect. In alpha.8 the same property inside
// .createMachine(...) is accepted by TypeScript but did not enforce this check.
const malformed = transition(machine, initial, {
  type: "APPROVE", approvalId: "approval-7", deliveryId: 42,
} as unknown as typeof approve);
same(malformed[0].value, "waiting", "malformed event cannot advance");
check(malformed[1].some((fx) => fx.type === "@xstate.deadLetter"), "invalid input has a rejection descriptor");

const replay = transition(machine, initial, approve);
same(replay[1].map(describeExecutableEffect), descriptors, "replay computes same command descriptors");
const duplicate = transition(machine, next, approve);
check(isUnhandled(next, duplicate), "duplicate approval has no transition and no command");

const saved = JSON.parse(JSON.stringify(machine.getPersistedSnapshot(next)));
const restored = machine.restoreSnapshot(saved);
same(restored.value, "executing", "snapshot restores without an actor or Promise");
same(restored.context, input, "context round trips");
check(isUnhandled(restored, transition(machine, restored, approve)), "restored state also rejects duplicate approval");
const [done, doneEffects] = transition(machine, restored, { type: "COMPLETE" });
same(done.status, "done", "restored machine can advance");
check(doneEffects.length === 1 && doneEffects[0].type === "@xstate.terminate", "root completion has a lifecycle descriptor");

// An Effect action is described by a pure transition; it is not executed.
let actionEffectRuns = 0;
const effectsMachine = setupEffect({
  actions: { audit: () => Effect.sync(() => { actionEffectRuns += 1; }) },
}).createMachine({
  initial: "idle",
  states: {
    idle: {
      on: {
        GO: (args, enq) => {
          enq(args.actions.audit);
          return { target: "recorded" };
        },
      },
    },
    recorded: {},
  },
});
const [beforeEffect] = initialTransition(effectsMachine);
const [, deferredEffects] = transition(effectsMachine, beforeEffect, { type: "GO" });
same(actionEffectRuns, 0, "pure transition did not run the Effect action");
check(deferredEffects.some((e) => e.kind === "action"), "Effect action returned an executable descriptor");

// Guardrail: the supported subset must reject actor/timer/executable effects,
// and copy ONLY the application command payload into its outbox. Never persist
// these executable closures or silently discard an unsupported effect. Handle
// root termination (stored terminal state) and rejected events explicitly.
console.log(JSON.stringify({
  result: "PASS",
  checks: ["synchronous decision", "immutable previous state", "JSON command", "runtime event validation", "deterministic replay", "duplicate no-op", "snapshot restore", "restored transition", "root completion descriptor", "Effect action not executed"],
  versions: { effect: "4.0.5", xstate: "6.0.0-alpha.68", xstateEffect: "1.0.0-alpha.8" },
  command: emitted.event,
  descriptorKind: emitted.kind,
  actionEffectRuns,
}, null, 2));
