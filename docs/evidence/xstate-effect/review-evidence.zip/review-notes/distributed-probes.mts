import assert from "node:assert/strict"
import { Effect, Exit, Scope } from "../durable-pi/node_modules/effect/dist/index.js"
import { makeNodeSqlite } from "../durable-pi/src/storage/node.ts"
import { migrateSqlite } from "../durable-pi/src/storage/migrations.ts"
import { SqliteBackgroundMailbox } from "../durable-pi/src/delegation/adapters/background-mailbox.ts"
import { makeBackgroundMailbox } from "../durable-pi/src/delegation/background-mailbox.ts"
import { makeBackgroundDelegation } from "../durable-pi/src/delegation/background-service.ts"
import { DelegationFailure } from "../durable-pi/src/delegation/contracts.ts"
import { resolveRoute } from "../durable-pi/src/inference/policy.ts"
import { ConversationStore } from "../durable-pi/src/conversations/adapters/sqlite-turns.ts"
import { EmailStore } from "../durable-pi/src/email/adapters/sqlite.ts"
import { emailPump } from "../durable-pi/src/email/pump.ts"

const run = Effect.runPromise
const scope = Scope.makeUnsafe()
const createDb = async () => {
  const db = await run(makeNodeSqlite().pipe(Effect.provideService(Scope.Scope, scope)))
  await run(migrateSqlite(db))
  return db
}
try {
  const db = await createDb()
  const route = { ...resolveRoute("conversation", { model: "gpt-6-luna", thinking: "low" }), contextWindow: 8192 }
  const mailbox = makeBackgroundMailbox(new SqliteBackgroundMailbox(db), () => Effect.succeed("active"), "owner-bot", () => crypto.randomUUID(), Effect.succeed(1000))
  const source = { turnId: crypto.randomUUID(), conversationId: 1, taskId: 19, route, memory: "Reference" }
  await run(mailbox.create({ objective: "Draft", tasks: [{ name: "Child", task: "Draft a paragraph", tools: [] }] }, source))
  let stopCalls = 0
  const app = makeBackgroundDelegation(mailbox, {
    start: () => Effect.die(new Error("cancelled work should not start")),
    read: () => Effect.die(new Error("unused")),
    stop: () => Effect.sync(() => { stopCalls++ }).pipe(Effect.andThen(Effect.fail(new DelegationFailure({ code: "unavailable", message: "Remote unavailable" })))),
    control: () => Effect.succeed({ accepted: true }),
    transcript: () => Effect.succeed({ entries: [], cursor: null }),
  }, {
    active: () => Effect.succeed(false),
    backgroundActive: () => Effect.succeed(false),
    wakeConversation: () => Effect.void,
    wakeBackground: () => Effect.void,
    notify: () => Effect.void,
    admission: { transactionGroup: db, stop: () => Effect.void, admit: () => Effect.die(new Error("cancelled report should not be admitted")) },
  })
  const stopped = await run(app.stop(19))
  await run(app.step())
  await run(app.step())
  const row = await run(mailbox.get(19))
  const nextWake = await run(mailbox.nextWake())
  assert.equal(row?.status, "cancelled")
  assert.equal(stopCalls, 1)
  assert.equal(nextWake, undefined)
  assert.equal(await run(mailbox.authorized(19)), false)
  console.log(JSON.stringify({ probe: "background-remote-stop-outage", stopResult: stopped, parentStatus: row?.status, stopCallsAfterTwoReconciliations: stopCalls, nextWake: nextWake ?? null, futureModelRequestsAuthorized: false, result: "confirmed: remote stop is not durably retried" }))

  const db2 = await createDb()
  const store = new EmailStore(db2)
  const conversations = new ConversationStore(db2, { model: "test", thinking: "off" })
  const id = crypto.randomUUID()
  const admission = await run(conversations.admit({ operationId: id, text: "Reply please" }))
  await run(store.receive({ id, fingerprint: "a".repeat(64), messageId: "<probe@example.com>", sender: "owner@example.com", recipient: "private@agents.example.com", subject: "Probe", body: "Reply please", references: "" }, (await run(store.settings())).generation))
  let sends = 0
  const pump = emailPump(store, {
    active: () => Effect.succeed(true),
    admit: () => Effect.void,
    turn: () => Effect.succeed({ ...admission.turn, status: "done", answer: "Reply" }),
    reviewUrl: () => Effect.succeed("https://pi.example.com/agents/personal-assistant"),
    send: () => Effect.sync(() => `provider-${++sends}`),
  })
  const sql = (query: string) => run(db2.use((orm) => orm._.session.prepareQuery({ sql: query, params: [] }, "objects", false, "run").run()))
  await run(pump())
  assert.equal((await run(store.get(id)))?.state, "waiting")
  await sql("CREATE TRIGGER reject_reply_checkpoint BEFORE UPDATE ON email_messages WHEN OLD.state='sending' AND NEW.state='sending' BEGIN SELECT RAISE(ABORT,'probe checkpoint storage failure'); END")
  const failed = await Effect.runPromiseExit(pump())
  assert(Exit.isFailure(failed))
  await sql("DROP TRIGGER reject_reply_checkpoint")
  const next = await run(pump())
  const stuck = await run(store.get(id))
  assert.equal(stuck?.state, "sending")
  assert.equal(sends, 1)
  assert.equal(next, undefined)
  await run(store.recover())
  const recovered = await run(store.get(id))
  assert.equal(recovered?.state, "uncertain")
  console.log(JSON.stringify({ probe: "reply-same-isolate-checkpoint-failure", providerCalls: sends, stateAfterStorageRecoveredAndPumpRetried: stuck?.state, confirmedParts: stuck?.delivery?.receipts.length, nextWake: next ?? null, stateAfterExplicitOnStartRecovery: recovered?.state, result: "confirmed: pump cannot recover sending intent without onStart/recover" }))
} finally {
  await run(Scope.close(scope, Exit.void))
}
