import { Clock, Context, Deferred, Effect, Exit, Fiber, Layer, Scheduler } from "../durable-pi/node_modules/effect/dist/index.js"
import { makeNodeSqlite } from "../durable-pi/src/storage/node.ts"
import { migrateSqlite } from "../durable-pi/src/storage/migrations.ts"
import { TerminalStore } from "../durable-pi/src/terminal/adapters/sqlite.ts"
import { TerminalService, terminalLayer } from "../durable-pi/src/terminal/terminal.ts"

const trial = (holdDatabase: boolean, maxOps = 2048, duplicate = false) => Effect.scoped(Effect.gen(function* () {
  const db = yield* makeNodeSqlite()
  yield* migrateSqlite(db)
  const repository = new TerminalStore(db)
  yield* repository.configure(0, true)
  const workRelease = yield* Deferred.make<void>()
  const executed: string[] = []
  const services = yield* Layer.build(terminalLayer({
    repository,
    runtime: {
      close: () => Effect.void,
      settle: () => Effect.void,
      restore: () => Effect.void,
      execute: (command: string) => Effect.sync(() => { executed.push(command) }).pipe(Effect.andThen(Deferred.await(workRelease)), Effect.as(0)),
      snapshot: () => Effect.succeed(new Uint8Array([1])),
      importFile: () => Effect.void,
      exportFile: () => Effect.succeed(new Uint8Array([1])),
      openInteractive: () => Effect.die("Unexpected interactive call"),
    },
    backups: {
      read: () => Effect.succeed(new Uint8Array([1])),
      write: () => Effect.succeed({ key: "probe", savedAt: 1, size: 1 }),
      settle: () => Effect.void,
    },
    relay: () => { throw new Error("Unexpected socket") },
    digest: () => Effect.succeed("digest"),
  }))
  const terminal = Context.get(services, TerminalService)
  const dbEntered = yield* Deferred.make<void>()
  const dbRelease = yield* Deferred.make<void>()
  const blocker = holdDatabase ? yield* db.transaction(() => Deferred.succeed(dbEntered, undefined).pipe(Effect.andThen(Deferred.await(dbRelease)))).pipe(Effect.forkChild) : undefined
  if (blocker) yield* Deferred.await(dbEntered)
  const first = yield* terminal.start({ id: "first", command: "first" }).pipe(Effect.exit, Effect.forkChild)
  const second = yield* terminal.start({ id: duplicate ? "first" : "second", command: duplicate ? "first" : "second" }).pipe(Effect.exit, Effect.forkChild)
  yield* Effect.yieldNow
  if (blocker) {
    yield* Deferred.succeed(dbRelease, undefined)
    yield* Fiber.join(blocker)
  }
  const firstResult = yield* Fiber.join(first)
  const secondResult = yield* Fiber.join(second)
  yield* Effect.yieldNow
  const running = (yield* repository.list()).map((r) => ({ id: r.id, status: r.status }))
  yield* Deferred.succeed(workRelease, undefined)
  for (const result of [firstResult, secondResult]) {
    if (Exit.isSuccess(result)) yield* result.value.completion
  }
  return {
    holdDatabase,
    maxOps,
    duplicate,
    firstAccepted: Exit.isSuccess(firstResult),
    secondAccepted: Exit.isSuccess(secondResult),
    executed,
    runningAtAdmission: running,
    saved: (yield* repository.list()).map((r) => ({ id: r.id, status: r.status })),
  }
})).pipe(Effect.provideService(Scheduler.MaxOpsBeforeYield, maxOps))

async function main() {
  for (const maxOps of [2048, 512, 128, 32]) for (const held of [false, true]) {
    try { console.log(JSON.stringify(await Effect.runPromise(trial(held, maxOps)))) }
    catch (cause) { console.error(String(cause)); process.exitCode = 1 }
  }
  for (const held of [false, true]) {
    try { console.log(JSON.stringify(await Effect.runPromise(trial(held, 128, true)))) }
    catch (cause) { console.error(String(cause)); process.exitCode = 1 }
  }
}
void main()
