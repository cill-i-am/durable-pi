# Targeted Vitest baseline

Repository: `cill-i-am/durable-pi` at `d29803bc8fd8020cefffb5ce08a02a84a2e4f1df`.

**PASS: 34 test files, 382 tests passed, zero failed, zero pending, zero todo.**

Started: 2026-10-19T11:15:39.266000+00:00. Approximate observed wall interval in the JSON report: 6.461 seconds.

The Vitest JSON also reports 59 total/passed suites because that field includes nested `describe` suites; the report contains 34 file entries. The file count is derived from `testResults.length`, and test totals are copied from the original report.

This is a selected architectural/regression baseline, not the complete repository verification pipeline. Original JSON is retained unchanged as `targeted-baseline.json`; its absolute source paths are historical diagnostics, not executable imports.

| Test file | Passed assertions | Result | File interval (ms) |
|---|---:|---|---:|
| `tests/access-coordination.test.ts` | 4 | passed | 286.99 |
| `tests/access-domain.test.ts` | 2 | passed | 40.59 |
| `tests/access-remember.test.ts` | 12 | passed | 562.29 |
| `tests/apps.test.ts` | 18 | passed | 662.56 |
| `tests/background-mailbox.test.ts` | 38 | passed | 1016.77 |
| `tests/browser.test.ts` | 32 | passed | 682.31 |
| `tests/communication-application.test.ts` | 14 | passed | 639.00 |
| `tests/communication-domain.test.ts` | 2 | passed | 19.03 |
| `tests/communication-native.test.ts` | 5 | passed | 520.67 |
| `tests/conversation-admission.test.ts` | 12 | passed | 515.03 |
| `tests/conversation-commands.test.ts` | 4 | passed | 8.86 |
| `tests/conversation-domain.test.ts` | 5 | passed | 181.38 |
| `tests/conversation-journal.test.ts` | 9 | passed | 458.62 |
| `tests/conversation-pump.test.ts` | 13 | passed | 702.89 |
| `tests/conversation-resume.test.ts` | 4 | passed | 54.06 |
| `tests/delegation-native.test.ts` | 10 | passed | 1447.39 |
| `tests/email.test.ts` | 32 | passed | 736.24 |
| `tests/pi-approvals.test.ts` | 7 | passed | 698.70 |
| `tests/pi-commit-failure.test.ts` | 9 | passed | 148.22 |
| `tests/pi-conversation-pump.test.ts` | 1 | passed | 163.98 |
| `tests/pi-loop-recovery.test.ts` | 12 | passed | 1643.60 |
| `tests/pi-steering.test.ts` | 3 | passed | 366.15 |
| `tests/planning-boundary.test.ts` | 11 | passed | 202.29 |
| `tests/planning-evidence.test.ts` | 3 | passed | 195.57 |
| `tests/planning.test.ts` | 10 | passed | 677.08 |
| `tests/reply-delivery.test.ts` | 13 | passed | 531.32 |
| `tests/reply-progress.test.ts` | 2 | passed | 4.23 |
| `tests/routines.test.ts` | 18 | passed | 634.82 |
| `tests/task-channel-controls.test.ts` | 5 | passed | 246.36 |
| `tests/task-controls.test.ts` | 5 | passed | 14.11 |
| `tests/terminal-coordination.test.ts` | 1 | passed | 87.38 |
| `tests/terminal.test.ts` | 37 | passed | 3169.46 |
| `tests/webhooks.test.ts` | 19 | passed | 885.74 |
| `tests/whatsapp.test.ts` | 10 | passed | 515.08 |
