# Durable Pi state-machine review: evidence bundle

## Reviewed source and purpose

Repository: [cill-i-am/durable-pi](https://github.com/cill-i-am/durable-pi).

Pinned review commit: `d29803bc8fd8020cefffb5ce08a02a84a2e4f1df` (main when checked on 19 October 2026).

This bundle contains the executable review probes and the recorded validation evidence. It does not contain the product repository, dependencies, screenshots, credentials, raw research notes, or the full written architectural review. Product code was not edited by these probes. Two staged probe imports use the adjacent checkout layout described below; only the distributed probe's Effect import needed rewriting from its original absolute path.

The recorded validation runtime was Node.js **24.19.0**. The available pnpm CLI was **11.25.0**; the repository's `packageManager` field declares **12.14.0**. Reproduction commands below invoke the installed Node entry points directly after dependency installation. The isolated XState feasibility probe has its own exact package and npm lock files.

## Results and qualifications

| Evidence | Recorded result | What the result establishes |
|---|---|---|
| Targeted repository Vitest tests | 34 files / 382 tests passed; 0 failures, pending or todo | A selected regression baseline passed on this commit. The original report's 59 suite count includes nested suites. This is not a claim that the complete verify pipeline ran. |
| Distributed probes | Both assertions passed | A remote background Stop outage is not durably retried after parent cancellation; an email acknowledgement followed by a failed local checkpoint remains `sending` on the next same-instance pump until explicit startup recovery. |
| Terminal admission probe | Overlap and a duplicate dispatch were observed at forced lower scheduler budgets | A scheduler-sensitive application admission defect under the actual Node SQLite adapter, with a synthetic executor. Normal short paths at 2048/512 operations per yield admitted one distinct command. At 128/32, two distinct commands could execute concurrently; with a held database transaction at 128, identical command IDs could dispatch twice while retaining one row. |
| Native storage/Lifecycle/Pi checks | 5 transaction/interoperability cases and 4 persisted-state checks after SIGKILL/restart passed | Local workerd exercised actual DO SQLite, native Pi harness and Lifecycle interaction, rollback, suspension, queued cancellation and lost acknowledgement. These selected checks are not the full native runtime matrix or an end-to-end provider scenario. |
| `@xstate/effect` API feasibility | PASS, 10 checks | Pinned alpha APIs support pure synchronous transition decisions, JSON command extraction, input validation, deterministic replay, duplicate no-op, snapshot restoration and deferred Effect action descriptions. This is not a production persistence, scheduler, outbox or workflow adapter. |

**Provider boundary:** all provider/executor behavior in the review probes is synthetic. No probe establishes live email, WhatsApp, model provider, remote shell or deployed Cloudflare behavior. The native workerd checks run locally; restart/SQLite/Pi evidence is not evidence of live provider acceptance.

**Terminal qualification:** lowering `Scheduler.MaxOpsBeforeYield` deliberately exposes yields in the application service. The real Node SQLite adapter and production Terminal service are used. Cloudflare's native transaction adapter suppresses scheduler yields inside its own transaction callback, while the application admission sequence spans more than one operation. This proves a port/application concurrency weakness under the tested schedule, not a measured live Cloudflare incident or its frequency. The Terminal script is an observational diagnostic; its JSON output must be inspected, since its zero exit code does not itself assert that a race occurred on every possible runtime.

**Distributed findings:** the reply probe does not show an automatic duplicate send; one accepted provider message becomes locally unconfirmed. Explicit `recover()` transitions it to `uncertain`. Background cancellation continues to deny future provider requests and result delivery; current background children are text-only and tool-free. The missing guarantee is durable remote-stop acknowledgement/retry.

## Expected directory layout

Extract the archive into a working directory, then place the pinned repository checkout beside `review-notes`.

| Relative path | Role |
|---|---|
| `README.md` | This guide |
| `MANIFEST.json` | SHA-256 and size of every other bundled file |
| `review-notes/distributed-probes.mts` | Distributed cancellation/reply recovery probes |
| `review-notes/terminal-admission-probe.ts` | Terminal concurrent-admission diagnostic |
| `review-notes/*.log` | Recorded outputs |
| `review-notes/targeted-baseline.json` | Unmodified original Vitest result |
| `review-notes/vitest-summary.md` | Compact extracted test-file summary |
| `review-notes/xstate-probe/` | Independent pinned API feasibility probe, manifest/lock and PASS output |
| `durable-pi/` | Required adjacent checkout; deliberately excluded from archive |

All executable probe imports are relative or package imports. Absolute source filenames within the original Vitest JSON are retained as historical diagnostics and require no rewriting to run the staged probes.

## Set up the pinned checkout

Run from the directory containing this README after extraction. GitHub access to the repository and package-registry access are required to fetch code/dependencies.

```sh
git clone https://github.com/cill-i-am/durable-pi.git durable-pi
git -C durable-pi checkout --detach d29803bc8fd8020cefffb5ce08a02a84a2e4f1df
cd durable-pi
pnpm install --frozen-lockfile --ignore-scripts
```

Use the repository-supported package manager and Node 24.19.0 for a close reproduction. Do not substitute newer dependency versions; the repository lockfile and isolated XState lockfile define the tested versions. The archive does not include `node_modules` or an npm cache.

## Reproduce distributed findings

From `durable-pi/`:

```sh
node --import ./node_modules/tsx/dist/loader.mjs ../review-notes/distributed-probes.mts
```

Expected output contains `background-remote-stop-outage` with one Stop call after two reconciliations, parent `cancelled`, no next wake and future authorization false; and `reply-same-isolate-checkpoint-failure` with one provider call, state `sending` after storage recovery and pump retry, no next wake, and `uncertain` after explicit recovery. Assertions make unexpected outcomes fail the process. Captured review output is `review-notes/distributed-probes.log`.

## Reproduce Terminal scheduling diagnostic

From `durable-pi/`:

```sh
node --import ./node_modules/tsx/dist/loader.mjs ../review-notes/terminal-admission-probe.ts
```

Compare `executed`, `runningAtAdmission`, both acceptance flags and `duplicate` in each JSON row. `review-notes/terminal-admission-probe.log` preserves all ten tested schedules, including the normal-budget controls and lower-budget cases. Interpret it using the Node SQLite qualification above.

## Reproduce the exact selected native cases

From `durable-pi/`:

```sh
node scripts/test-drizzle-runtime.mjs \
  guarded-pi-harness \
  guarded-suspension \
  guarded-queued-cancellation \
  guarded-app-rollback-lifecycle-write \
  guarded-lost-ack
```

The script builds a local fixture, starts workerd with temporary SQLite storage, executes the five cases, forcibly stops/restarts it and verifies four cases with persisted-state snapshots. It uses temporary files and a local port. The recorded output is `review-notes/native-storage-check.log`. Expected final line: `PASS native Drizzle proof: 5 transaction/interoperability cases and 4 persisted-state checks after SIGKILL/restart.`

## Reproduce the targeted Vitest baseline

From `durable-pi/`, run the following exact file selection. The output goes to a new filename so the recorded original remains unchanged.

```sh
node ./node_modules/vitest/vitest.mjs run \
  tests/access-coordination.test.ts \
  tests/access-domain.test.ts \
  tests/access-remember.test.ts \
  tests/apps.test.ts \
  tests/background-mailbox.test.ts \
  tests/browser.test.ts \
  tests/communication-application.test.ts \
  tests/communication-domain.test.ts \
  tests/communication-native.test.ts \
  tests/conversation-admission.test.ts \
  tests/conversation-commands.test.ts \
  tests/conversation-domain.test.ts \
  tests/conversation-journal.test.ts \
  tests/conversation-pump.test.ts \
  tests/conversation-resume.test.ts \
  tests/delegation-native.test.ts \
  tests/email.test.ts \
  tests/pi-approvals.test.ts \
  tests/pi-commit-failure.test.ts \
  tests/pi-conversation-pump.test.ts \
  tests/pi-loop-recovery.test.ts \
  tests/pi-steering.test.ts \
  tests/planning-boundary.test.ts \
  tests/planning-evidence.test.ts \
  tests/planning.test.ts \
  tests/reply-delivery.test.ts \
  tests/reply-progress.test.ts \
  tests/routines.test.ts \
  tests/task-channel-controls.test.ts \
  tests/task-controls.test.ts \
  tests/terminal-coordination.test.ts \
  tests/terminal.test.ts \
  tests/webhooks.test.ts \
  tests/whatsapp.test.ts \
  --reporter=json \
  --outputFile=../review-notes/targeted-baseline-rerun.json
```

The original `targeted-baseline.json` is 129,625 bytes. `vitest-summary.md` lists the 34 files and assertion counts. Full production build, browser matrix, all native-runtime scenarios, container checks, load tests and live provider acceptance are outside the claims of this bundle.

## Reproduce XState/Effect API feasibility

From the extraction directory, install only the probe's pinned dependencies and run its TypeScript directly with Node 24.19.0:

```sh
cd review-notes/xstate-probe
npm ci --ignore-scripts
node probe.ts
../../durable-pi/node_modules/.bin/tsc --noEmit --strict --skipLibCheck --target ES2022 --module NodeNext --moduleResolution NodeNext --lib ES2022,DOM probe.ts
```

Pinned versions are `effect@4.0.5`, `xstate@6.0.0-alpha.68` and `@xstate/effect@1.0.0-alpha.8`. The recorded `probe.log` is the stdout of a successful review rerun (`node probe.ts`, exit code 0). It reports all ten checks. The probe creates no running actor and performs no network/database action; it evaluates transitions and command descriptors only.

A production adapter must still decide how state, accepted event and durable command intent commit atomically, how attempts are claimed/fenced, how provider uncertainty is handled, how snapshots migrate and how Lifecycle derives the next wake. Executable effect closures are not portable outbox records. The alpha subset must reject unsupported actor/timer/executable descriptors rather than silently discarding them. The probe explicitly demonstrates that an Effect action descriptor is produced without running the action.

## Integrity

`MANIFEST.json` records SHA-256 and byte size for each bundled file except itself. The original JSON/logs and the Terminal/XState source copies are byte-for-byte copies of their review evidence. The distributed source copy differs only in its Effect import, rewritten to `../durable-pi/node_modules/effect/dist/index.js` for the documented adjacent-checkout layout. The ZIP contains no dependencies or repository source tree.
